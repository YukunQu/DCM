function [hd,sd] = get_homedir

% [homedir,scratchdir] = get_homedir
%
% LH Macbook Pro - returns homedir and scratchdir locations

hd = '/Users/lhunt/home';
sd = '/Users/lhunt/scratch';


